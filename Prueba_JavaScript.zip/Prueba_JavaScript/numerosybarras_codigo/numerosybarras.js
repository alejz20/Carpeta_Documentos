
let numerosGuardados = [];

// CREANDO BOTONES

 // Boton_Guardar
var botonGuardar = document.createElement('button');
botonGuardar.innerHTML = 'Guardar'; // innerHTML crea el objeto en el html, en este caso un boton
botonGuardar.classList.add('ctrlBtn'); // Agrega la clase "ctrlBtn" al boton
botonGuardar.addEventListener('click', () =>{
    var numero = inputElement.value;
    if(numero >=1 && numero <=10){

        if(numerosGuardados.length < 4){
            numerosGuardados.push(numero);
            cuadroElement.innerHTML = numero;
            VisorElement.innerHTML = 'Numero correcto guardado';
        }else {
            VisorElement.innerHTML = 'No se se admite más números. Pulsa reiniciar';
        }
    }else if(numero == ''){
        VisorElement.innerHTML = 'Escribe un numero';
    }else{
        VisorElement.innerHTML = 'Numero incorrecto';
    }
  
});

 // Boton_Resetear
var botonResetear = document.createElement('button');
botonResetear.innerHTML = 'Reiniciar'; //// innerHTML crea el objeto en el html, en este caso un boton
botonResetear.classList.add('ctrlBtn'); // Agrega la clase "ctrlBtn" al boton
botonResetear.addEventListener('click', function(){
numerosGuardados.length = 0;
VisorElement.innerHTML = '';
cuadroElement.innerHTML = 'NaN';
barboxDiv.innerHTML = '';
});

 // Boton_Dibujar
var botonDibujar = document.createElement('button');
botonDibujar.innerHTML = 'Dibujar';   //// innerHTML crea el objeto en el html, en este caso un boton
botonDibujar.classList.add('ctrlBtn'); // Agrega la clase "ctrlBtn" al boton
botonDibujar.addEventListener('mouseout', function() {
    barboxDiv.innerHTML = ""; 
    for (let i = 0; i < numerosGuardados.length; i++) {
        const numero = numerosGuardados[i];
        const barra = document.createElement('div');
        barra.classList.add('bar');
        barra.style.width = (numero * 35) + 'px'; 
        barboxDiv.appendChild(barra);
    }

});


//  CONTENEDOR --> Controlbox
var contenedorBotones = document.getElementById("controlbox");
contenedorBotones.appendChild(botonGuardar);
contenedorBotones.appendChild(botonDibujar);
contenedorBotones.appendChild(botonResetear);



// Creando el span de texto
var spanElement = document.createElement("span");
var textoNode = document.createTextNode('Escribe un numero del 1 al 10: ');
spanElement.appendChild(textoNode);

contenedorBotones.appendChild(spanElement);

// Creando el input de tipo text
const inputElement = document.createElement('input');
inputElement.setAttribute('type','text');
inputElement.setAttribute('maxlength', 2);
inputElement.setAttribute('id', 'numbertxt');

inputElement.classList.add('numbertxt');
contenedorBotones.appendChild(inputElement);



// Creando el cuadrado del numero
const contenedorNumber = document.getElementById('numberbox'); // CONTENEDOR --> Numberbox
var cuadroElement = document.createElement('div'); 

contenedorNumber.appendChild(cuadroElement); // CUADRADO --> al CONTENEDOR div 'numberbox'
contenedorNumber.setAttribute('id','numero');
cuadroElement.classList.add('number');

cuadroElement.textContent = 'NaN'; 


// CONTENEDOR --> Visor

const VisorElement = document.getElementById('visor');

// CONTENEDOR --> Barbox

const barboxDiv = document.getElementById('barbox');


