import java.io.*;
import java.util.*;

public class FileTest {

	public static void main(String[] args) {
		String nombreFichero = "./src/FileTest.java";
		File f = new File(nombreFichero);
		
		System.out.println(f.exists() ? "existe" : "no existe");
		if (f.isDirectory()) {
			System.out.println("El directorio " + nombreFichero + " contiene:");
			for (String s : f.list()) {
				System.out.println("\t" + s);
			}
		}
		System.out.print(f.canRead() ? "r" : "-");
		System.out.print(f.canWrite() ? "w" : "-");
		System.out.println(f.canExecute() ? "x" : "-");
		System.out.println(new Date(f.lastModified()));
		System.out.println(f.getAbsolutePath());
		System.out.println(f.getPath());
		System.out.println(f.getName());
		System.out.println(f.length());
		try {
			System.out.println(f.getCanonicalPath());
			System.out.println(f.getCanonicalFile());
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}