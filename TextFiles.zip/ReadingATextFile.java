import java.io.*;
import java.util.*;

public class ReadingATextFile {
	
	final static String PATH = "./src/LeerFicheroTexto.java";
	final static int BLOCK_SIZE = 10000;

	public static void FBufferedInputStream() throws Exception {
		InputStream f = new FileInputStream(PATH);
		BufferedInputStream r = new BufferedInputStream(f);
		int offset = 0;
		int length = BLOCK_SIZE;
		int readed;
		byte[] buffer = new byte[length];
		while ((readed = r.read(buffer, offset, length)) > 0) {
			for (int i=0; i<readed; i++) {
				System.out.print((char) buffer[i]);
			}
		}
		r.close();
		f.close();
	}

	public static void FReader() throws Exception {
		File f = new File(PATH);
		Reader r = new FileReader(f);
		int offset = 0;
		int length = BLOCK_SIZE;
		int readed;
		char[] buffer = new char[length];
		while ((readed = r.read(buffer, offset, length)) > 0) {
			System.out.print(Arrays.copyOf(buffer, readed));
		}
		r.close();
	}

	public static void FBufferedReader() throws Exception {
		FileReader f = new FileReader(PATH);
		BufferedReader r = new BufferedReader(f);
		String linea;
		while ((linea = r.readLine()) != null) {
			System.out.println(linea);
		}
		r.close();
		f.close();
	}

	public static void FScanner() throws Exception {
		File f = new File(PATH);
		Scanner r = new Scanner(f);
		while (r.hasNextLine()) {
			System.out.println(r.nextLine());
		}
		r.close();
	}
	
	public static void FRandomAccessFile() throws Exception {
		String mode = "r";
		RandomAccessFile r = new RandomAccessFile(PATH, mode);
		while (r.getFilePointer() < r.length()) {
			System.out.println(r.readLine());
		}
		r.close();
	}

	public static void main(String[] args) throws Exception {
		System.out.println("************ BufferedInputStream ***************");
		FBufferedInputStream();
		System.out.println("************ Reader ****************************");
		FReader();
		System.out.println("************ BufferedReader ********************");
		FBufferedReader();
		System.out.println("************ Scanner ***************************");
		FScanner();
		System.out.println("************ RandomAccessFile ******************");
		FRandomAccessFile();
		System.out.println("************ The end ***************************");
	}

}
