/**
 * Ejemplo simple de encriptaci�n tipo C�sar
 * 
 * Es una de las t�cnicas de cifrado m�s simples y m�s usadas. Es un tipo de cifrado por sustituci�n 
 * en el que una letra en el texto original es reemplazada por otra letra que se encuentra un n�mero 
 * fijo de posiciones m�s adelante en el alfabeto.
 * 
 * @author Amadeo Mora
 */
import java.io.*;

public class CesarEncryption {
	
	/**
	 * M�todo de encriptaci�n
	 * 
	 * @param shift Desplazamiento dentro del alfabeto
	 * @param text Texto a encriptar
	 * @param file Fichero donde se almacena la informaci�n ecnriptada
	 * @throws Exception
	 */
	public static void encrypt(int shift, String text, String file) throws Exception {
		// Preparo el texto encriptado
		byte[] bytes = text.getBytes();
		for (int i=0; i<bytes.length; i++) {
			bytes[i] += shift;
		}
		
		// Escribo el desplazamiento y el texto en un fichero
		RandomAccessFile raf = new RandomAccessFile(file, "rw");
		raf.setLength(0);
		raf.writeInt(shift);
		raf.write(bytes);
		raf.close();
	}

	/**
	 * Lectura del fichero sin conocer el formato de la informaci�n
	 * 
	 * @param file
	 */
	public static void readFile(String file) {
		RandomAccessFile raf = null;
		try {
			raf = new RandomAccessFile(file, "r");
			while (raf.getFilePointer() < raf.length()) {
				int b = raf.readUnsignedByte();
				System.out.printf("%c", b);
			}
			raf.close();
		} catch (Exception e) {
			System.err.println(e);
		}
	}

	/**
	 * Lectura del fichero conociendo su estructura y sem�ntica
	 * 
	 * @param file
	 */
	public static void decrypt(String file) {
		RandomAccessFile raf = null;
		try {
			raf = new RandomAccessFile(file, "r");
			// Obtenemos el desplazamiento a realizar en el texto
			int shift = raf.readInt();
			// Leemos caracter a caracter realizando el desplazamiento
			while (raf.getFilePointer() < raf.length()) {
				int b = raf.readUnsignedByte();
				b -= shift;
				System.out.printf("%c", b);
			}
			raf.close();
		} catch (Exception e) {
			System.err.println(e);
		}
	}

	/**
	 * Programa principal
	 * 
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		String text = "Mar�a ama a P�o"; 
		int shift = 3;
		
		System.out.format("%nEncripto \"%s\" con un desplazamiento %d y lo almaceno%n", text, shift);
		encrypt(3, text, "encriptado.bin");
		
		System.out.format("%nMuestro el fichero sin desencriptar (raw mode):%n");
		readFile("encriptado.bin");

		System.out.format("%nMuestro el fichero desencriptado:%n");
		decrypt("encriptado.bin");
	}
}
